import json
import os
import boto3
from botocore.exceptions import ClientError

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = os.environ.get("DYNAMODB_TABLE", "VanityNumbers")

def lambda_handler(event, context):
    
    table = dynamodb.Table(TABLE_NAME)
    
    items = []
    try:
        # scan all rows from VanityNumbers, paginate results if the table is large
        scan_kwargs = {}
        while True:
            response = table.scan(**scan_kwargs)
            items.extend(response.get('Items', []))
            
            # Continue scanning if there are more pages
            start_key = response.get('LastEvaluatedKey')
            if not start_key:
                break
            scan_kwargs['ExclusiveStartKey'] = start_key
            
    except ClientError as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'text/html'},
            'body': f"<h3>Error fetching data from VanityNumbers table: {e.response['Error']['Message']}</h3>"
        }

    # Basic CSS Styling
    css_styles = """
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f7f6; margin: 0; padding: 40px; color: #333; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 2px; margin-bottom: 12px;}
        th, td { text-align: left; padding: 12px 15px; border-bottom: 1px solid #ddd; }
        th { background-color: #3498db; color: white; text-transform: uppercase; font-size: 14px; letter-spacing: 0.5px; }
        tr:hover { background-color: #f9f9f9; }
        .no-records { padding: 40px; text-align: center; color: #7f8c8d; font-size: 18px; border: 2px dashed #bdc3c7; border-radius: 6px; background-color: #fafafa; }
        .badge { background-color: #2ecc71; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
    </style>
    """

    # Build HTML response
    html_content = f"<!DOCTYPE html><html><head><title>Vanity Numbers Inventory</title>{css_styles}</head><body>"
    html_content += "<div class='container'><h2>Vanity Numbers Directory</h2>"

    # CONDITION CHECK: Empty Table Handling
    if not items:
        html_content += "<div class='no-records'><h3>No records found</h3><p>The VanityNumbers table is currently empty.</p></div>"
    else:
        # Dynamically build html table headers based on keys found in the DynamoDB table rows
        headers = sorted(list(set(key for item in items for key in item.keys())))
        
        html_content += "<table ><thead><tr>"
        for header in headers:
            html_content += f"<th>{header}</th>"
        html_content += "</tr></thead><tbody>"

        # Generate table body rows
        for item in items:
            html_content += "<tr>"
            for header in headers:
                # Safely get key value, defaulting to empty string if a column is missing on a specific row
                val = item.get(header, "")
                
                # Highlight the actual vanity numbers
                if "vanity" in header.lower() and val:
                    html_content += f"<td>"
                    
                    # Extract the nested VanityNumbers array (fall back to empty list if missing)
                    vanity_list = val
                    if isinstance(vanity_list, str):
                        try:
                            vanity_list = json.loads(vanity_list)
                        except:
                            vanity_list = []

                    # If this caller has no vanity options generated, display an alert row
                    if not vanity_list:
                        html_content += "<table><tr><td style='color: #a0aec0; padding: 20px; text-align: center;'>No vanity options calculated for this number.</td></tr></table>"
                    else:
                        # Loop through each option in the nested VanityNumbers attribute array
                        for index, option in enumerate(vanity_list, 1):
                            # Safely retrieve nested values
                            score = option.get('score', 'N/A')
                            vanity_val = option.get('vanity', 'N/A')
                            word = option.get('word', 'N/A')
                            word_length = option.get('word_length', 'N/A')
                                                        
                            # Output the attributes as separate rows inside a table structure
                            html_content += f"<table>"
                            html_content += f"  <tr style='background-color: #f8fafc;'><th colspan='2' style='color: #4a5568;'>Option #{index}</th></tr>"
                            html_content += f"  <tr><th>Vanity Number</th><td>{vanity_val}</td></tr>"
                            html_content += f"  <tr><th>Converted Word</th><td><span class='word-text'>{word}</span></td></tr>"
                            html_content += f"  <tr><th>Word Length</th><td><span class='length-badge'>{word_length} characters</span></td></tr>"
                            html_content += f"  <tr><th>Generation Score</th><td><span class='score-badge'>{score}</span></td></tr>"
                            html_content += f"</table>"
                    html_content += f"</td>"

                else:
                    html_content += f"<td>{val}</td>"
            html_content += "</tr>"
            
        html_content += "</tbody></table>"

    html_content += "</div></body></html>"

    # Return valid HTTP response
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/html',
            'Access-Control-Allow-Origin': '*'
        },
        'body': html_content
    }
