"""
Unit tests for vanity_converter.py

Run with:
    cd vanity-number-lambda
    python -m pytest tests/ -v
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../src"))

import pytest
from vanity_converter import (
    word_to_digits,
    generate_vanity_numbers,
    letter_to_digit,
    DIGIT_TO_LETTERS,
)


# ---------------------------------------------------------------------------
# letter_to_digit / word_to_digits
# ---------------------------------------------------------------------------

class TestKeypadMapping:
    def test_all_letters_map_to_digits(self):
        all_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        for ch in all_letters:
            d = letter_to_digit(ch)
            assert d.isdigit(), f"{ch} should map to a digit, got {d!r}"

    def test_vowels_map_correctly(self):
        assert letter_to_digit("A") == "2"
        assert letter_to_digit("E") == "3"
        assert letter_to_digit("I") == "4"
        assert letter_to_digit("O") == "6"
        assert letter_to_digit("U") == "8"

    def test_word_flowers(self):
        assert word_to_digits("FLOWERS") == "3569377"

    def test_word_home(self):
        assert word_to_digits("HOME") == "4663"

    def test_word_call(self):
        assert word_to_digits("CALL") == "2255"

    def test_case_insensitive(self):
        assert word_to_digits("flowers") == word_to_digits("FLOWERS")


# ---------------------------------------------------------------------------
# generate_vanity_numbers
# ---------------------------------------------------------------------------

class TestGenerateVanityNumbers:
    WORD_LIST = [
        "flowers", "flow", "lower", "owe", "home", "help",
        "call", "sale", "care", "zero", "hero", "love",
        "over", "move", "more", "core", "bore", "fore",
        "zone", "tone", "bone", "done", "gone", "lone",
        "phone", "score", "store", "shore",
    ]

    def test_returns_list(self):
        result = generate_vanity_numbers("18003569377", self.WORD_LIST)
        assert isinstance(result, list)

    def test_max_5_results(self):
        result = generate_vanity_numbers("18003569377", self.WORD_LIST)
        assert len(result) <= 5

    def test_flowers_detected(self):
        # 1-800-FLOWERS = 1-800-356-9377
        result = generate_vanity_numbers("18003569377", self.WORD_LIST)
        vanities = [r["vanity"] for r in result]
        assert any("FLOWERS" in v for v in vanities), f"Expected FLOWERS in {vanities}"

    def test_scores_descending(self):
        result = generate_vanity_numbers("18003569377", self.WORD_LIST)
        scores = [r["score"] for r in result]
        assert scores == sorted(scores, reverse=True), "Results should be sorted by score desc"

    def test_scores_in_range(self):
        result = generate_vanity_numbers("18003569377", self.WORD_LIST)
        for r in result:
            assert 0.0 <= r["score"] <= 1.0, f"Score out of range: {r['score']}"

    def test_strips_leading_1(self):
        # +1 country code should be stripped
        r1 = generate_vanity_numbers("18003569377", self.WORD_LIST)
        r2 = generate_vanity_numbers("8003569377", self.WORD_LIST)
        assert [x["vanity"] for x in r1] == [x["vanity"] for x in r2]

    def test_invalid_number_raises(self):
        with pytest.raises(ValueError):
            generate_vanity_numbers("123", self.WORD_LIST)

    def test_no_matches_returns_empty(self):
        result = generate_vanity_numbers("1111111111", self.WORD_LIST)
        # 1s have no letters, so nothing should match
        assert result == []

    def test_longer_word_scores_higher_than_shorter(self):
        # "flowers" (7 letters) should outscore "flow" (4 letters) at same position
        result = generate_vanity_numbers("18003569377", self.WORD_LIST)
        words_found = {r["word"]: r["score"] for r in result}
        if "FLOWERS" in words_found and "FLOW" in words_found:
            assert words_found["FLOWERS"] > words_found["FLOW"]

    def test_result_fields_present(self):
        result = generate_vanity_numbers("18003569377", self.WORD_LIST)
        for r in result:
            assert "vanity" in r
            assert "score" in r
            assert "word" in r
            assert "digits" in r
            assert "word_length" in r

    def test_top_n_respected(self):
        result = generate_vanity_numbers("18003569377", self.WORD_LIST, top_n=3)
        assert len(result) <= 3


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_number_with_dashes(self):
        result = generate_vanity_numbers("1-800-356-9377", ["flowers"])
        assert len(result) >= 1

    def test_number_with_spaces(self):
        result = generate_vanity_numbers("1 800 356 9377", ["flowers"])
        assert len(result) >= 1

    def test_e164_format(self):
        result = generate_vanity_numbers("+18003569377", ["flowers"])
        # +1 prefix stripped → still 10 digits
        assert len(result) >= 1

    def test_empty_word_list(self):
        result = generate_vanity_numbers("18003569377", [])
        assert result == []

    def test_very_short_words_ignored(self):
        # Words < 3 chars should be skipped
        result = generate_vanity_numbers("18003569377", ["ab", "bc"])
        assert result == []
