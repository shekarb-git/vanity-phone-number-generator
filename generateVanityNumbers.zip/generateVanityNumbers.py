# AWS Lambda for the Vanity Number lookup service.
# Lambda returns an attribute map that Connect can read as
# $.Attributes in the contact flow:
#  BestVanity1 … BestVanity5 : the vanity strings
#  CallerNumber              : normalized E.164 number

import json
import logging
import os
from typing import List, Optional

import boto3
from botocore.exceptions import ClientError
from vanity_converter import generate_vanity_numbers

# Logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


# DynamoDB client (module-level so they are reused across warm invocations)
dynamodb = boto3.resource("dynamodb")

# For the purpose of POC, all potential words are stored in the words.txt file
WORDS_FILE = "words.txt"
_WORD_LIST: Optional[List[str]] = None

def load_words() -> List[str]:
    global _WORD_LIST
    if _WORD_LIST is None:
        logger.info("Loading word list from %s", WORDS_FILE)
        with open(WORDS_FILE, "r") as fh:
            _WORD_LIST = [
                w.strip().lower()
                for w in fh
                if w.strip() and not w.startswith("#") and len(w.strip()) >= 3
            ]
        logger.info("Loaded %d words", len(_WORD_LIST))
    return _WORD_LIST


# Helper method: extract PhoneNumber from Connect event
def extract_caller_number(event: dict) -> str:
    # Amazon Connect passes the caller's number in: event["Details"]["ContactData"]["Parameters"]["PhoneNumber"]
    # For unit testing pass caller's number directly as event["PhoneNumber"]
    
    try:
        return event.get('Details', {}).get('Parameters', {}).get('PhoneNumber')
    except (KeyError, TypeError):
        pass

    # Fallback for unit tests / direct invocations
    if "PhoneNumber" in event:
        return event["PhoneNumber"]

    raise ValueError("Cannot extract phone number from event payload.")


# Save Vanity Number in DynamoDB table
def _save_to_dynamodb(caller_number: str, vanity_numbers: List[dict]) -> None:
    TABLE_NAME = os.environ.get("DYNAMODB_TABLE", "VanityNumbers")
    table = dynamodb.Table(TABLE_NAME)
    # Persist the top-5 vanity numbers for the caller
    item = {
        "CallerNumber": caller_number,
        #"Timestamp": now.isoformat(),
        "VanityNumbers": [
            {
                "vanity": v["vanity"],
                "score": str(v["score"]),  
                "word": v["word"],
                "word_length": v["word_length"],
            }
            for v in vanity_numbers
        ],
        "RawDigits": vanity_numbers[0]["digits"] if vanity_numbers else "",
    }

    try:
        # ConditionExpression ensures it only adds if the CallerNumber isn't in the DB
        table.put_item(
            Item=item,
            ConditionExpression="attribute_not_exists(CallerNumber)"
        )
        logger.info("Saved %d vanity numbers for %s", len(vanity_numbers), caller_number)

    except ClientError as exc:
        # Check if the error is specifically due to the item already existing
        if exc.response["Error"]["Code"] == "ConditionalCheckFailedException":
            logger.info("Skipped saving: Item already exists for caller %s", caller_number)
        else:
            # Log other database errors (e.g., permissions, throughput) but don't crash the call flow
            # Log but don't crash — the call should still continue even if DB write fails
            logger.error(
                "DynamoDB put_item failed for %s: %s",
                caller_number,
                exc.response["Error"]["Message"],
            )


# Lambda handler
def lambda_handler(event: dict, context) -> dict:
    
    # main method for lambda function, reads ContactData from Amazon Connect flow
    # returns list of vanity numbers via via $.Attributes
    logger.info("Received event: %s", json.dumps(event))

    # Extract caller number
    try:
        caller_number = extract_caller_number(event)
        logger.info("Processing call from %s", caller_number)
    except ValueError as exc:
        logger.error(str(exc))
        return {"Error": str(exc)}

    # Generate vanity candidates
    word_list = load_words()
    try:
        top_vanity = generate_vanity_numbers(caller_number, word_list, top_n=5)
    except ValueError as exc:
        logger.error("Vanity generation failed: %s", exc)
        return {"Error": str(exc), "CallerNumber": caller_number}

    logger.info(
        "Top vanity numbers for %s: %s",
        caller_number,
        [v["vanity"] for v in top_vanity],
    )

    # Save to DynamoDB
    if top_vanity:
        _save_to_dynamodb(caller_number, top_vanity)

    # Connect reads string attributes — pad to 5 slots with empty strings.
    response: dict = {"CallerNumber": caller_number}
    for i in range(5):
        key = f"BestVanity{i + 1}"
        response[key] = top_vanity[i]["vanity"] if i < len(top_vanity) else ""

    logger.info("Returning attributes: %s", response)
    return response
