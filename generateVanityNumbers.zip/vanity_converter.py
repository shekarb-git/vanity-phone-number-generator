"""
vanity_converter.py
-------------------
Core logic for converting a phone number's digits into candidate vanity numbers
and scoring them to find the "best" ones.

SCORING PHILOSOPHY
==================
"Best" vanity numbers are those a human would actually want on a business card.
We rank candidates by a weighted composite score:

  1. Dictionary word length (weight: 60%)
     Longer real words are far more memorable than short ones.
     "1-800-FLOWERS" beats "1-800-FL0WER-5".

  2. Word position (weight: 20%)
     Words at the *end* of the number are more readable because callers hear
     digits first and the word last — the part they remember.
     A word covering the final 4+ digits scores highest.

  3. Coverage (weight: 20%)
     The fraction of the 10 digits (area code + 7-digit local) that the word
     replaces. More letter coverage → easier to recall.

Only the last 7 digits are considered for word substitution (standard US
practice), but scoring uses the full 10-digit number for coverage ratio.

A word dictionary ships with the Lambda as a plain-text file derived from a
curated subset of common English words (nouns, verbs, adjectives ≥ 4 letters).
"""

import re
from typing import List

# Phone keypad mapping  (digit → possible letters)
DIGIT_TO_LETTERS = {
    "2": "ABC",
    "3": "DEF",
    "4": "GHI",
    "5": "JKL",
    "6": "MNO",
    "7": "PQRS",
    "8": "TUV",
    "9": "WXYZ",
    "0": "",   # 0 and 1 have no letters on a standard keypad
    "1": "",
}

LETTER_TO_DIGIT = {}
for digit, letters in DIGIT_TO_LETTERS.items():
    for letter in letters:
        LETTER_TO_DIGIT[letter] = digit


def letter_to_digit(ch: str) -> str:
    return LETTER_TO_DIGIT.get(ch.upper(), ch)


def word_to_digits(word: str) -> str:
    # Convert a word to its digit sequence.
    return "".join(letter_to_digit(c) for c in word.upper())


# Vanity number generator
def generate_vanity_numbers(phone_number: str,  word_list: List[str], top_n: int = 5,) -> List[dict]:
    
    # Finds and scores vanity phrases for a given 10-digit phone number.
    # Args:
    #    phone_number: A normalized string of 10 digits (e.g., "8003569377").
    #        Must not contain a country code, spaces, or punctuation.
    #    word_list: A list of dictionary words to match against the digits.
    #        Words will be scored on length, position, and coverage.
    #    top_n: The maximum number of high-scoring results to return.

    # Returns:
    #    A list of dictionaries ordered by score descending. Each dict contains:
    #        - vanity (str): The formatted vanity number, e.g., "800-FLOWERS".
    #        - score (float): The composite quality score bounded between 0 and 1.
    #        - word (str): The matched candidate word.
    #        - digits (str): The original 10-digit sequence.
    #    e.g., { "vanity":  "800-FLOWERS", "score":   0.87, "word": "FLOWERS", "digits":  "8003569377",}

    digits = re.sub(r"\D", "", phone_number)
    if digits.startswith("1") and len(digits) == 11:
        digits = digits[1:]          # strip leading country code
    if len(digits) != 10:
        raise ValueError(f"Expected a 10-digit US number, got: {phone_number!r}")

    local_digits = digits[3:]        # last 7 digits (after area code)
    candidates = []

    for word in word_list:
        word_upper = word.upper()
        word_digits = word_to_digits(word_upper)
        word_len = len(word_digits)

        if word_len < 3 or word_len > 7:
            continue                 # too short to be memorable or too long to fit

        # Slide the word across the 7 local digits
        for start in range(len(local_digits) - word_len + 1):
            if local_digits[start: start + word_len] == word_digits:
                # Build the pretty vanity string, keeping the word segment intact
                pre_local = local_digits[:start]
                post_local = local_digits[start + word_len:]
                area = digits[:3]
                parts = [p for p in [pre_local, word_upper, post_local] if p]
                vanity = area + "-" + "-".join(parts)

                score = vanity_score(
                    word_len=word_len,
                    start_in_local=start,
                    local_len=len(local_digits),
                    total_len=len(digits),
                )

                candidates.append({
                    "vanity": vanity,
                    "score": round(score, 4),
                    "word": word_upper,
                    "digits": digits,
                    "word_length": word_len,
                    "position": start,
                })

    # De-duplicate by vanity string, keeping highest score
    seen = {}
    for c in candidates:
        key = c["vanity"]
        if key not in seen or c["score"] > seen[key]["score"]:
            seen[key] = c

    ranked = sorted(seen.values(), key=lambda x: x["score"], reverse=True)
    return ranked[:top_n]


def vanity_score(word_len: int, start_in_local: int, local_len: int, total_len: int) -> float:

    # Calculates a composite score bounded between 0 and 1.

    # The score evaluates substitution quality based on three distinct metrics:
    # - Word Length: Normalized against a maximum substitutable length of 7 digits.
    # - Position: Evaluates proximity to the end; 
    #   words ending at the final digit score 1.0, while earlier positions yield lower scores.
    # - Coverage: The ratio of word length to the total string length (10 digits).

    # Returns: A composite score strictly within the interval.
    
    word_length_score = word_len / 7.0                           # max 7 local digits
    end_pos = start_in_local + word_len                          # 1-indexed end in local
    position_score = end_pos / local_len                         # 1.0 if word ends last
    coverage_score = word_len / total_len                        # fraction of full number

    return (
        0.60 * word_length_score
        + 0.20 * position_score
        + 0.20 * coverage_score
    )
